#include "ram.h"
#include <iostream>

using namespace std;

memory r(4), m(1024);

void program()
{
  //Load in memory
  reset(3); //Flag, 0 if equal.
  reset(0);
  inc(0);
  load(1,0);
  inc(0);
  load(2,0);

  reset(0); 
 repeat: //Start comprobation
  dec(1);
  dec(2);
  cgoto(1, a1);
  cgoto(2, b1);
  cgoto(0, end);

 a1:
  cgoto(2, repeat);
  inc(3);
  cgoto(0, end);

 b1:
  cgoto(1, repeat);
  inc(3);
  cgoto(0, end);

 end:
  reset(0);
  store(3,0);
  
}

int main()
{
  int a, b;
  // RAM data input (memory initialization).
  cout << "First number ";
  cin >> a;

  cout << "Second number ";
  cin >> b;
  
  
  m[1] = a;
  m[2] = b;

  // Program execution.
    program();
    
  // RAM data output (memory reading).
  if(m[0] == 0)
    cout << "True" << endl;
  else
    cout << "False" << endl;
}

