#include "ram.h"
#include <iostream>
#include <ctime>

using namespace std;

void program()
{
  //Load registers begin(1) and end(2)
  reset(0);
  reset(1);
  reset(5);
  load(2, 0); 
  inc(2); //After label begin register number 2 decrement
  
 begin:
  inc(1);
  dec(2);
  reset(0);
  cgoto(2, carga);
  cgoto(0, end);
  
 carga:
  load(3,1);
  load(4,2);
  
 repeat: //Check if  r3 != r4
  dec(3);
  dec(4);
  cgoto(3, a1);
  cgoto(4, b1);
  cgoto(0,end); //Both numbers are equal

 a1:
  cgoto(4, repeat);
  inc(5);
  cgoto(5, end);

 b1:
  cgoto(3, repeat);
  inc(5);
  cgoto(5, end);

 end: //Store r5 in m[0]
  reset(0);
  cgoto(2,begin);
  store(5,0); 
  
}

memory r(20), m(1024);

int main()
{
  string numero;
  cout << "Introduzca un numero binario: ";
  getline(cin,  numero);
  m[0] = numero.size();
  string::size_type i;
  for(i = 0; i < numero.size(); i++)
  {
    m[i+1] = static_cast<int>(numero[i]) - 48;
  }
  
  m[i+1] = 0; //Inicializamos una posicion mas para el correcto funcionamiento del alg. 
  
  //RAM program execution and timing
  program(); 
  
  if(m[0] == 1) //1 because compares the first position with length value
    cout << "True" << endl;
  else
    cout << "False" << endl;
  
  return 0;
}
